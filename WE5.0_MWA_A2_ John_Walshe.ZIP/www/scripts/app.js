angular.module("todoListApp", [])
;
//Could be depencies, config and stuff here. Useful to keep bare 